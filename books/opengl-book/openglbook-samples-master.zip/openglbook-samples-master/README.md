openglbook-samples
==================

This repository contains the source code in C for the chapters at
[openglbook.com](http://openglbook.com/). Please consult your compiler's
documentation on how to compile these files.

Dependencies are not included, please download and install
[GLEW](http://glew.sourceforge.net/) and
[FreeGLUT](http://freeglut.sourceforge.net/) before compiling.
